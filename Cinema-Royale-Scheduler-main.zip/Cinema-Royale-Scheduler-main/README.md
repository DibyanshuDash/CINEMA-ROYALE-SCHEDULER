# 🎬 Cinema Royale: The Scheduler

A visual simulation game for an Operating Systems course project that demonstrates CPU scheduling algorithms. The player acts as a ticket booth operator, serving customers based on FCFS, SJF, and Priority scheduling rules.

---

### Video Demo

A video showcasing the gameplay and features.

**[Click here to watch the demo video.](assets/demo-video.mp4)**

---

### Screenshots

**Main Menu**
![Screenshot of the main menu showing algorithm choices](assets/screenshot-menu.png)

**Gameplay (Shortest Job First)**
![Screenshot of SJF gameplay with customers in the queue](assets/screenshot-gameplay.png)

**Priority Scheduling**
![Screenshot showing customers with different priority sashes](assets/screenshot-priority.png)

---

## ⚙️ How to Set Up and Run

### Prerequisites
* Python 3.x
* Pygame library

### Instructions
1.  **Clone the repository:**
    ```bash
    git clone [https://github.com/your-username/Cinema-Royale-Scheduler.git](https://github.com/your-username/Cinema-Royale-Scheduler.git)
    cd Cinema-Royale-Scheduler
    ```
2.  **Create a virtual environment (recommended):**
    ```bash
    # For macOS/Linux:
    python3 -m venv venv && source venv/bin/activate
    # For Windows:
    python -m venv venv && .\\venv\\Scripts\\activate
    ```
3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```
4.  **Run the game:**
    ```bash
    python3 game.py
    ```