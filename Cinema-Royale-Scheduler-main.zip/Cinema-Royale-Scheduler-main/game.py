import pygame
import random
import time
import math

# 1. Initialize Pygame
pygame.init()

# --- Theme Constants ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
LOBBY_BG = (20, 20, 30)
FONT_COLOR = (230, 210, 180)
GOLD_COLOR = (212, 175, 55)
RED_VELVET_COLOR = (138, 7, 7)
PRIORITY_SASH_COLORS = [(0, 255, 0), (100, 255, 0), (255, 255, 0), (255, 165, 0), (255, 0, 0)] # Green (High) to Red (Low)

# --- Game Setup ---
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Cinema Royale: The Scheduler")
try:
    font = pygame.font.Font("PlayfairDisplay-Regular.ttf", 32)
    small_font = pygame.font.Font("PlayfairDisplay-Regular.ttf", 24)
    ui_font = pygame.font.Font("PlayfairDisplay-Regular.ttf", 40)
except FileNotFoundError:
    print("Font file not found! Using default font.")
    font = pygame.font.Font(None, 36)
    small_font = pygame.font.Font(None, 28)
    ui_font = pygame.font.Font(None, 44)
clock = pygame.time.Clock()

# --- Game State ---
game_state = "menu"
selected_algorithm = None
ticket_line = []
active_customer = None

# --- Stats Tracking ---
customers_served = 0
total_service_time = 0.0
customer_arrival_count = 0 # New variable for FCFS numbering

class Customer:
    def __init__(self):
        global customer_arrival_count
        customer_arrival_count += 1
        self.arrival_id = customer_arrival_count # Assign a unique arrival ID
        
        self.order_time = random.randint(5, 25) # For SJF
        self.time_left = self.order_time # The serving time countdown
        self.arrival_time = time.time() # For FCFS
        self.priority = random.randint(1, 5) # For Priority (1 is highest)
        self.rect = pygame.Rect(100, 50, 50, 80)
        self.color = (10, 10, 10) # Silhouette

class TicketStub:
    # (Animation for when a customer is finished)
    def __init__(self, start_pos):
        self.rect = pygame.Rect(start_pos[0], start_pos[1], 25, 15)
        self.target_pos = (SCREEN_WIDTH / 2, 40)
        self.speed = 8
        self.angle = math.atan2(self.target_pos[1] - self.rect.y, self.target_pos[0] - self.rect.x)
        self.vel_x = math.cos(self.angle) * self.speed
        self.vel_y = math.sin(self.angle) * self.speed
    def update(self):
        self.rect.x += self.vel_x
        self.rect.y += self.vel_y
        return self.rect.collidepoint(self.target_pos)
    def draw(self, surface):
        pygame.draw.rect(surface, (255, 255, 255), self.rect, border_radius=2)

def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, True, color)
    text_rect = text_obj.get_rect(center=(x, y))
    surface.blit(text_obj, text_rect)

def reset_game():
    global ticket_line, active_customer, last_spawn_time, customers_served, total_service_time, customer_arrival_count
    ticket_line = []
    active_customer = None
    last_spawn_time = time.time()
    customers_served = 0
    total_service_time = 0.0
    customer_arrival_count = 0 # Reset the arrival counter

# 2. Main Game Loop
running = True
ticket_stubs = []

while running:
    current_time = time.time()
    mouse_pos = pygame.mouse.get_pos()
    
    # --- Event Handling ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if game_state == "menu":
                for i, alg in enumerate(["FCFS", "SJF", "Priority"]):
                    button_rect = pygame.Rect(SCREEN_WIDTH/2 - 150, 200 + i*90, 300, 70)
                    if button_rect.collidepoint(mouse_pos):
                        selected_algorithm = alg
                        game_state = "playing"
                        reset_game()
                        break
            
            elif game_state == "playing":
                if not active_customer:
                    correct_customer = None
                    if ticket_line:
                        if selected_algorithm == "FCFS":
                            correct_customer = min(ticket_line, key=lambda c: c.arrival_time)
                        elif selected_algorithm == "SJF":
                            correct_customer = min(ticket_line, key=lambda c: c.order_time)
                        elif selected_algorithm == "Priority":
                            correct_customer = min(ticket_line, key=lambda c: c.priority)
                    
                    for customer in ticket_line:
                        if customer.rect.collidepoint(mouse_pos) and customer == correct_customer:
                            active_customer = customer
                            ticket_line.remove(customer)
                            break
    
    # --- Game Logic ---
    if game_state == "playing":
        if current_time - last_spawn_time > 2.5 and not active_customer:
            if len(ticket_line) < 7:
                ticket_line.append(Customer())
            last_spawn_time = current_time

        if active_customer:
            active_customer.time_left -= 1/60.0
            if active_customer.time_left <= 0:
                customers_served += 1
                total_service_time += active_customer.order_time
                ticket_stubs.append(TicketStub((SCREEN_WIDTH - 200, 250)))
                active_customer = None

        for stub in ticket_stubs[:]:
            if stub.update():
                ticket_stubs.remove(stub)

    # --- Drawing ---
    screen.fill(LOBBY_BG)
    if game_state == "menu":
        draw_text("Select an Algorithm", ui_font, GOLD_COLOR, screen, SCREEN_WIDTH/2, 120)
        for i, alg in enumerate(["FCFS", "SJF", "Priority"]):
            button_rect = pygame.Rect(SCREEN_WIDTH/2 - 150, 200 + i*90, 300, 70)
            pygame.draw.rect(screen, RED_VELVET_COLOR, button_rect, border_radius=10)
            draw_text(alg, font, FONT_COLOR, screen, button_rect.centerx, button_rect.centery)
    
    elif game_state == "playing":
        pygame.draw.line(screen, RED_VELVET_COLOR, (20, 20), (20, SCREEN_HEIGHT - 20), 8)
        pygame.draw.line(screen, RED_VELVET_COLOR, (270, 20), (270, SCREEN_HEIGHT - 20), 8)
        pygame.draw.rect(screen, (250,250,250), (SCREEN_WIDTH - 350, 200, 300, 150), border_top_left_radius=10, border_top_right_radius=10)
        draw_text("Box Office", font, (0,0,0), screen, SCREEN_WIDTH - 200, 230)
        
        draw_text(f"Customers Served: {customers_served}", font, FONT_COLOR, screen, SCREEN_WIDTH / 2, 40)
        draw_text(f"Total Service Time: {total_service_time:.1f}s", font, FONT_COLOR, screen, SCREEN_WIDTH / 2, 80)
        
        rules = {
            "FCFS": "Rule: Serve the FIRST customer in line (Lowest #)",
            "SJF": "Rule: Serve customer with LOWEST service time",
            "Priority": "Rule: Serve customer with HIGHEST priority (Lowest #)"
        }
        draw_text(rules.get(selected_algorithm, ""), small_font, GOLD_COLOR, screen, SCREEN_WIDTH / 2, 120)

        for i, customer in enumerate(ticket_line):
            customer.rect.y = 80 + i * 90
            
            correct_customer = None
            if ticket_line:
                if selected_algorithm == "FCFS": correct_customer = min(ticket_line, key=lambda c: c.arrival_time)
                elif selected_algorithm == "SJF": correct_customer = min(ticket_line, key=lambda c: c.order_time)
                elif selected_algorithm == "Priority": correct_customer = min(ticket_line, key=lambda c: c.priority)
            
            if customer == correct_customer:
                spotlight_surf = pygame.Surface(customer.rect.size, pygame.SRCALPHA)
                pygame.draw.ellipse(spotlight_surf, (255, 255, 200, 70), (0, 0, customer.rect.width, customer.rect.height))
                screen.blit(spotlight_surf, customer.rect.topleft)

            pygame.draw.rect(screen, customer.color, customer.rect, border_radius=3)
            
            # --- Conditionally draw info based on algorithm ---
            if selected_algorithm == "FCFS":
                draw_text(f"#{customer.arrival_id}", font, FONT_COLOR, screen, customer.rect.centerx, customer.rect.centery)
            elif selected_algorithm == "SJF":
                draw_text(f"{customer.order_time}s", small_font, FONT_COLOR, screen, customer.rect.centerx, customer.rect.centery)
            elif selected_algorithm == "Priority":
                sash_rect = pygame.Rect(customer.rect.topleft[0], customer.rect.topleft[1]+20, customer.rect.width, 15)
                pygame.draw.rect(screen, PRIORITY_SASH_COLORS[customer.priority-1], sash_rect)
                draw_text(f"P: {customer.priority}", small_font, (0,0,0), screen, sash_rect.centerx, sash_rect.centery)
        
        if active_customer:
            draw_text(f"Serving... {active_customer.time_left:.1f}s", small_font, (0,0,0), screen, SCREEN_WIDTH - 200, 280)
        
        for stub in ticket_stubs:
            stub.draw(screen)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()